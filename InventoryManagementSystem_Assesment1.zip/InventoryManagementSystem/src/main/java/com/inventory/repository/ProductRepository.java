package com.inventory.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.inventory.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer>  {


	/*String deleteProductByRating();

	Optional<Product> findProductCategory(String category);

	Product findProductByName(String name);

	Product updateProductById(int productid, String category);

	List<Product> updateProductGrossPrice();

	Product save(Product product);

	List<Product> findAll();*/
	

	



	

}
