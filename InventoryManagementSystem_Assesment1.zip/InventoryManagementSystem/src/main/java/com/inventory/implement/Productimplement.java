package com.inventory.implement;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inventory.dao.ProductJpaDao;
import com.inventory.model.Product;


@Service
@Transactional
public class Productimplement {
	private static Logger LOGGER = LoggerFactory.getLogger(Productimplement.class);
	
	@Autowired
	private ProductJpaDao prodctJpaDao;
	
	public <Product> Product findProductByName(String name) {
		return (Product)ProductJpaDao.findProductByName(name).get();
		
	}

	
	  public Optional<Product> findProductCategory(String category) {
	 return ProductJpaDao.findProductCategory(category); }
	 

	public String deleteProductByRating() {
		ProductJpaDao.deleteProductByRating();
		return "deleted";
	}

}
