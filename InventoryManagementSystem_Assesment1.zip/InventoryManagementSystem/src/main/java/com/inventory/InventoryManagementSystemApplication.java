package com.inventory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.inventory.InventoryManagementSystemApplication;

@SpringBootApplication
public class InventoryManagementSystemApplication {
	 private static final Logger logger = LoggerFactory.getLogger(InventoryManagementSystemApplication.class);

	public static void main(String[] args) {
		
		logger.info("my project started===================");

		SpringApplication.run(InventoryManagementSystemApplication.class, args);
		
	}

}
