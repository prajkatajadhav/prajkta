package com.inventory.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.inventory.model.Product;
import com.inventory.repository.ProductRepository;

@RestController
@CrossOrigin(origins = "http://localhost:8080")
@RequestMapping("/api")
public class ProductController {
	
	
	private static Logger LOGGER = LoggerFactory.getLogger(ProductController.class);
	@Autowired
	private ProductRepository ProductRepository;
	private List<Product> products = new ArrayList<Product>();
	
	@PostMapping(value="/Products", consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Product> create_Product(@RequestBody Product product) {
		try {
			Product _Product = ProductRepository.save(
					new Product(product.getProductId(), product.getCategory(), product.getName(), product.getQuantity(),
							product.getUnitPrice(), product.getTotalPrice(), product.getRating()));
			return new ResponseEntity<>(_Product, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@GetMapping(value="/Products" , consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Product>> getAllProducts() {
		try {
			

			ProductRepository.findAll().forEach(products::add);

			if (products.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			return new ResponseEntity<>(products, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

	@PutMapping(value="/Products/{id}", consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
	public boolean updateProduct(@PathVariable("id")int productId, @RequestBody Product product){
		for(Product tempProduct : products) {
			if(tempProduct.getProductId()==productId) {
				tempProduct.setName(product.getName());
				tempProduct.setQuantity(product.getQuantity());
				tempProduct.setRating(product.getRating());
				tempProduct.setUnitPrice(product.getUnitPrice());

				}
			
		}
		return false;
	
		}
	
 

	 
	
	
		
		 
}
