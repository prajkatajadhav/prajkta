package com.inventory.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.inventory.model.Product;


public interface ProductJpaDao extends JpaRepository<Product, Integer> {

	static Optional<Product> findProductByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	static Optional<Product> findProductCategory(String category) {
		// TODO Auto-generated method stub
		return null;
	}

	static void deleteProductByRating() {
		// TODO Auto-generated method stub
		
	}
	
	
	/*@Query("select t from product t where t.name=:name")
	Optional<Product> findProductByName(String name);

	
	  @Query("select t from product t where t.category=:category")
	  Optional<Product> findProductCategory(String category);

	  @Query("delete from product t where t.rating<2")
	  int deleteProductByRating();
	  */

}
