package com.inventory.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inventory.dao.ProductJpaDao;
import com.inventory.model.Product;


@Service
public class productservice {
	@Autowired
	private ProductJpaDao productJpaDao;
	public Iterable<Product> getAllProducts() {
		return productJpaDao.findAll();
	}

	public Product createproduct(Product product) {
	        return productJpaDao.save(product); 
	}

	public Product updateProductById(Integer productid, String category) {
		Product smartshop = productJpaDao.findById(productid).get();
		smartshop.setCategory(category);
	        return productJpaDao.save(smartshop);
	}

	public Product findProductByName(String name) {
		return (Product)ProductJpaDao.findProductByName(name).get();
		
	}

	
	  public Optional<Product> findProductCategory(String category) {
	 return ProductJpaDao.findProductCategory(category); }
	 

	public String deleteProductByRating() {
		ProductJpaDao.deleteProductByRating();
		return "deleted";
	}

	
	public List<Product> updateProductGrossPrice() {
		List<Product> prod = new ArrayList<Product>();
		prod= (List<Product>) getAllProducts();
		for(Product ele : prod) {
			ele.setTotalPrice(ele.getUnitPrice()*ele.getQuantity());
		}
		return prod ;
	}
}
